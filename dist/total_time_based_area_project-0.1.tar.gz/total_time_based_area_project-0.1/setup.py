from setuptools import setup, find_packages

setup(
    name='total_time_based_area_project',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'requests',  # Assuming you are using requests for API calls
        'matplotlib',  # Assuming you are using matplotlib for data visualization
        # Add other dependencies as needed
    ],
    entry_points={
        'console_scripts': [
            'fall_detection_main = your_package_name.main_program:main',  # Adjust with your actual package and main program name
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
